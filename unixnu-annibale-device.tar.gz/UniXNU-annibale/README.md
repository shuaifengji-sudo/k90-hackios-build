# UniXNU-annibale

Xiaomi Redmi K90 (`annibale`, model `2510DRK44C`) device profile for UniXNU.
Target OS profile: iPadOS 17.7.11 (21H461), XNU format 2.

## Status

Scaffold only. No build has run and no device write has been made.

| Area | State |
|---|---|
| Board identity | measured / in `board.toml` |
| GPU | Adreno830v2 `0x44050001`; A830 source exists in `IssacL04/UniXNU-Pagani_SM8750` |
| Panel | NT37801 CSOT AMOLED, DSC; panel driver not ported |
| Touch | goodix; `PaganiInput` (S3910) is not compatible, new driver needed |
| UEFI | no `annibalePkg`; must derive from `ace6Pkg`/`paganiPkg` |
| Storage | **blocked**: no `unixnu` partition on K90 |
| Kernel | not built |
| Root/data | not built; iPadOS 17.7.11 IPSW not yet fetched |

## Hardware baseline

- SoC: SM8750 (`sun`), 8 cores, 16 GiB class.
- GPU: Adreno830v2, chipid `0x44050001`.
- Panel: `nt37801 amoled cmd mode dsi csot panel with DSC`; native 1440x3200, HackiOS presents 1156x2510.
- Touch: goodix on TLMM IRQ 162 / reset 161, panel max 115600x250904.
- UFS: `ufshc@1d84000`, 2 lanes.
- FDT: `D:\安卓刷ios\research\k90-fw\fdt` (912084 B, SHA-256 `9cad591a…`).
- DTBO: `annibale-backup/20261101-prehackios/raw/dtbo_a.img` / `dtbo_b.img` (25,165,824 B each).
- Android `userdata`: sectors 3518464..64041978 at 4096 bytes (230.9 GiB).

## Blocking issue: storage partition

UniXNU expects a partition named `unixnu` (or another dedicated block range).
K90 has no such partition. Creating one would modify GPT, and reusing `userdata`
would destroy Android data. Both are outside the current safety constraints.

Options, all need an explicit decision:

1. Add a dedicated `unixnu` partition from free/unused space (GPT change; destructive risk).
2. Use a file-backed UniXNU disk in Android `userdata` (DSU-like; no GPT change, but boot integration and free-space cost).
3. Boot a volatile RAM seed only (no persistence; good for bring-up).
4. Repurpose `userdata` (not acceptable without a full backup and explicit wipe consent).

`board.toml` currently records the real `userdata` range only as a reference;
`partition = "unixnu"` must not be pointed at it.

## Next steps

1. Derive `uefi/annibalePkg` from `ace6Pkg`/`paganiPkg` with K90 framebuffer and memory map.
2. Port `NativeMobileDisplay`/panel and a goodix input driver.
3. Build the UniXNU kernel with the A830 Pagani backend.
4. Decide the storage option before any payload/root work.
5. Fetch iPadOS 17.7.11 (21H461) IPSW and run the first build on macOS CI.

## Provenance

- Template: `xiaoan919/UniXNU-ace6` (same SM8750).
- GPU reference: `IssacL04/UniXNU-Pagani_SM8750` (A830, tested 28–40 FPS).
- Common platform: `IssacL04/UniXNU-sm8750-common`.
- K90 hardware: FDT/DTBO/vendor dumps from this device, 2026-11-02.
