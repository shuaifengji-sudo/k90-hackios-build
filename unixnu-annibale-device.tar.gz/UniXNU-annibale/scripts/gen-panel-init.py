import re

p = r"D:\安卓刷ios\research\k90-fw\k90.dts"
lines = open(p, encoding="utf-8").read().splitlines()
start = next(i for i, l in enumerate(lines)
             if 'nt37801 amoled cmd mode dsi csot panel with DSC"' in l)
prop = None
for l in lines[start:start + 40]:
    s = l.strip()
    if s.startswith("qcom,mdss-dsi-on-command = ["):
        prop = s
        break
assert prop is not None
toks = re.findall(r"[0-9a-fA-F]+", prop.split("[", 1)[1].rsplit("]", 1)[0])
# DTS sign-extends 32-bit values; keep the low byte.
vals = [int(t, 16) & 0xFF for t in toks]
packets = []
i = 0
# Qualcomm DSI packet header: dtype, last, vc, ack, wait, length_hi, length_lo.
while i + 7 <= len(vals):
    ln = (vals[i + 5] << 8) | vals[i + 6]
    if i + 7 + ln > len(vals):
        break
    packets.append(vals[i:i + 7 + ln])
    i += 7 + ln

out = [
    "/* Generated from K90 /sys/firmware/fdt: nt37801 on-command, timing@0. */",
    "#pragma once",
    "#include <stdint.h>",
    "struct annibale_dcs_packet { const uint8_t *data; uint16_t length; };",
]
for n, pk in enumerate(packets):
    out.append(f"static const uint8_t annibale_panel_on_{n}[] = {{" +
               ", ".join(f"0x{x:02x}" for x in pk) + "};")
out.append("static const struct annibale_dcs_packet annibale_panel_on[] = {")
for n, pk in enumerate(packets):
    out.append(f"  {{ annibale_panel_on_{n}, sizeof(annibale_panel_on_{n}) }},")
out.append("};")
out.append(f"/* {len(packets)} packets */")
open(r"D:\安卓刷ios\UniXNU-annibale\package\AnnibalePanelInit.h",
     "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
print("packets", len(packets), "bytes", len(vals))
