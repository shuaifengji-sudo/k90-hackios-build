﻿# UniXNU-annibale porting state

Date: 2026-11-02
Target: iPadOS 17.7.11 (21H461), XNU format 2, RAM seed only.

## Done

- `board.toml` identity adapted for K90 `annibale` / `2510DRK44C`.
- `dts/annibale.dts`: SM8750 CPU/GPU/UFS/SMMU nodes, high memory windows.
- `configs/annibale_defconfig`: SM8750 base, legacy display, no Adreno.
- `uefi/Platforms/Xiaomi/annibalePkg`: derived from `ace6Pkg`; platform name,
  SMBIOS, and framebuffer changed to 1156x2510.
- `package/PaganiPeripherals.h`: panel name/dimensions changed to NT37801 /
  1440x3200; brightness max remains 0xffe.
- Reused `PaganiPanel` for DSI brightness/blanking, because Stage7Probe's class
  and static-init symbols are tied to that name.

## Still missing

### 1. UEFI memory map

`annibalePkg/Library/MemoryMapLib/MemoryMapLib.c` now carries 47 K90 reserved-memory regions generated from the FDT, plus UEFI/FD/Heap/MMIO entries. Overlaps still need a build-time audit before flashing.
K90 reserved regions must be reconciled against
`D:\瀹夊崜鍒穒os\research\k90-fw\fdt` before flashing any UEFI image.
Do not treat the current `annibalePkg` as bootable.

### 2. goodix touch (in progress)

The scaffold has no `AnnibaleInput`; `PaganiInput` is Synaptics S3910 and must
not be included. The working reference is HackiOS
`xnu/files/bsd/dev/redwood_goodix.c` (23,561 B), but it is a BSD driver, not a
UniXNU IOKit component. It must be ported to the UniXNU component ABI and bound
to TLMM IRQ 162 / reset 161, SPI/Geni or the HackiOS transport.

### 3. Panel init

`PaganiPanel` only does DCS 0x51 brightness and 0x28/0x29 blanking. The physical
NT37801 DSI init/DSC sequence must come from the K90 vendor boot/kernel or a
working UEFI DisplayDxe profile. Without it, brightness commands may run but the
panel may not display.

### 4. Kernel build

No UniXNU kernel has been built. The A830 backend exists in
`IssacL04/UniXNU-Pagani_SM8750`; it should be brought in as a component/module,
not by replacing the K90 kernel with HackiOS.

### 5. RAM seed root

iPadOS 17.7.11 IPSW not fetched; Data seed not built. RAM seed is volatile and
does not require a `unixnu` partition.

## Safety

- Do not point `[userdata]` at the real K90 `userdata` range (3518464..64041978).
- Do not create a `unixnu` partition without an explicit GPT/data decision.
- No device write until `annibalePkg` memory map and panel/touch are verified.

## Next order

1. Build a K90 memory map from the FDT reserved-memory nodes; diff against Ace6.
2. Port goodix from `redwood_goodix.c` into `drivers/AnnibaleInput`.
3. Capture K90 NT37801 init sequence from vendor_boot/kernel.
4. Build the kernel with A830 Pagani backend.
5. Fetch 21H461 IPSW and create the RAM seed.



